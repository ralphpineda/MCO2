
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.Color;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


import java.awt.*;    
/**
 * This class is the View file from the MVC architecture. it handles the gui of the program
 * @author  Ralph Dawson G. Pineda
 */
public class GamePanel{
    private JFrame window;
    private JPanel topPanel, midPanel, botPanel;
    private JPanel titleNamePanel, startButtonPanel, choiceButtonPanel, playerPanel, farmPanel, inventoryPanel, tilePanel;
    private JLabel titleNameLabel;
    private JLabel  FeedbackLbl;
    private ArrayList<JLabel> tools, playerLbl;
    private Font titleFont  = new Font("Times New Roman", Font.PLAIN,90), 
                normalFont = new Font("Times New Roman", Font.PLAIN,30),
                smallFont = new Font("Times New Roman", Font.PLAIN, 15),
                buttonFont = new Font("Times New Roman", Font.PLAIN, 5);
    private Button startButton, ok;
    private ArrayList<ArrayList<Button>> buttonTiles;
    private ArrayList<Button> choices, interactTile,Equip;
    private JTextField mainTextArea;
    private JTextArea detailsLbl;
    private ActionListener intTileListen1,intTileListen2,intTileListen3,intTileListen4, choice1, choice2, choice3, choice4, plantListener,interact; 

    
/**
 * constructor method
 */
    public GamePanel()
    {
        //initialize
        //create frame and main panels
        initializeAttributes();
        //initializeTextPanel();
        createScreenPanel();
        //create homescreen
        createHomeScreen();
    }
    /**
     * This initializes mst of the attributes contained in this class
     */
    public void initializeAttributes()
    {
        //initialize arraylists
        detailsLbl = new JTextArea(5,20);
        detailsLbl.setBackground(Color.black);
        detailsLbl.setForeground(Color.white);
        detailsLbl.setFont(normalFont);
        playerPanel = new JPanel();
        playerLbl = new ArrayList<JLabel>();
        buttonTiles = new ArrayList<ArrayList<Button>>();
        interactTile = new ArrayList<Button>();
        choices = new ArrayList<Button>();
        tools = new ArrayList<JLabel>();
        interactTile = new ArrayList<Button>();
        choices = new ArrayList<Button>();
        tools = new ArrayList<JLabel>();
        choiceButtonPanel = new JPanel();
         choiceButtonPanel.setBackground(Color.black); 
         choiceButtonPanel.setLayout(new GridLayout(1,4)); 
         tilePanel = new JPanel(new GridLayout());
         mainTextArea = new JTextField(15);
        mainTextArea.setFont(smallFont);
        mainTextArea.setBackground(Color.white);
        mainTextArea.setForeground(Color.black);
        FeedbackLbl = new JLabel();
        FeedbackLbl.setFont(normalFont);
        FeedbackLbl.setBackground(Color.black);
        FeedbackLbl.setForeground(Color.white);
         Equip = new ArrayList<Button>();
        for(int i =0;i<5;i++)
        {
           // buttonTiles.add(new ArrayList<Button>());
           // for(int j = 0; j<10; j++)
                //buttonTiles.get(i).add(new Button());
            interactTile.add(new Button());
            choices.add(new Button());
            tools.add(new JLabel());
         //   Equip.add(new Button());
        }
        //initialize components
        inventoryPanel = new JPanel(new GridLayout(2,5));
        Equip = new ArrayList<Button>();
    }
    /**This method initializes the main frame and main panels (top, mid, bottom)*/
    public void createScreenPanel(){
        window = new JFrame("FarmLand");
        window.setSize(1000, 1000);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.black);
        topPanel = new JPanel(new BorderLayout());
       // topPanel.setLayout(new GridLayout(2,8));
        topPanel.setBackground(Color.black);
        topPanel.setForeground(Color.white);

        midPanel = new JPanel();
        midPanel.setLayout(new GridLayout(5,10));
        midPanel.setBackground(Color.black);
       // midPanel.setPreferredSize(new Dimension(700, 700));
        botPanel = new JPanel();//GridLayout(1,4));
        botPanel.setBackground(Color.black);
        window.add(topPanel, BorderLayout.NORTH);
        window.add(midPanel,BorderLayout.CENTER);
        window.add(botPanel, BorderLayout.SOUTH);
    }
 
    public void initializeChoiceButtonPanel(){
        for(int i=0;i<4;i++)
            choiceButtonPanel.add(choices.get(i),BorderLayout.CENTER);
    }

    /**This method creates the panels for home screen */
    public void createHomeScreen(){
        
        //Title 
        titleNamePanel = new JPanel(new BorderLayout());
      //  titleNamePanel.setBounds(250,100,600,150);
        titleNamePanel.setBackground(Color.black);
        titleNameLabel = new JLabel("Farm Land");
        titleNameLabel.setForeground(Color.white);
        titleNameLabel.setFont(titleFont); 
        //start button panel
        startButtonPanel = new JPanel();
        startButtonPanel.setBackground(Color.black);
        //start button
        startButton = new Button( "START");
        startButton.setBackground(Color.black);
        startButton.setForeground(Color.white);
        startButton.setFont(normalFont);
        startButtonPanel.add(startButton);
        titleNamePanel.add(titleNameLabel, BorderLayout.CENTER);
        topPanel.setLayout(new BorderLayout());
        topPanel.add(titleNamePanel,BorderLayout.CENTER);
        botPanel.add(startButtonPanel);
        window.setVisible(true);
        update();
    }
/**Thism ethod creates the panels for the game screen */
    public void createGameScreen(){
        //new game screen
        titleNamePanel.setVisible(false);
       startButtonPanel.setVisible(false);

        topPanel.setLayout(new GridLayout(2,9));

        farmPanel = new JPanel(new GridLayout(5,10));
   //

      //  farmPanel.setBounds(100,100,900, 350);
        farmPanel.setBackground(Color.black);
        initializeFarm(interact);
        topPanel.add(playerPanel);
        midPanel.add(farmPanel);
       // midPanel.add(mainTextArea,BorderLayout.SOUTH);
        
        //create frame and main panels
   
      ButtonChoice();
      initializeChoiceButtonPanel();
      botPanel.add(choiceButtonPanel);
        update();
    }
    /**
     * This method creates the panels and labels for player details on the top screen
     */
    public void initializeplayerPanel(ArrayList<String> details)
    {
        String[] titles = {"Name","Object Coins","Item Equipped","Level", "Experience","Rank","Date"};
        topPanel.removeAll();
        playerPanel = new JPanel(new GridLayout(2,5));
        playerPanel.setBackground(Color.black);
        playerPanel.setForeground(Color.white);
        if(playerLbl.size()==0){
            for(int i = 0;i<details.size();i++)
            {
                playerLbl.add(new JLabel(titles[i]));
                playerLbl.add(new JLabel(details.get(i)));
            }
            for(int j=0;j<playerLbl.size();j++)
                {
                    playerPanel.add(playerLbl.get(j));
                    playerLbl.get(j).setBackground(Color.black);
                    playerLbl.get(j).setForeground(Color.white);
                    playerLbl.get(j).setFont(smallFont);
                }
        }
            
        else
        {
            playerPanel.removeAll();
            int j=0;
            for(int i =1; i<playerLbl.size();i+=2)
            {
                playerLbl.get(i).setText(details.get(j));
                j++;
            }
            for(int k=0;k<playerLbl.size();k++)
                playerPanel.add(playerLbl.get(k));
            
        }   
        topPanel.add(playerPanel);
        update();         
    }
    /** This method displays the tools owned by the player */
    public void displayInventory(ActionListener action){
        inventoryPanel.setLayout(new GridLayout(2,5));
        inventoryPanel.setBackground(Color.black);
        inventoryPanel.setForeground(Color.white);
   
        botPanel.removeAll();
        
       String[] toolName = {"Plow", "Watering Can", "Fertilizer", "Pickaxe","Shovel"};
        for(int i = 0; i<5;i++)
        {
            tools.get(i).setBackground(Color.black);
            tools.get(i).setForeground(Color.white);
            tools.get(i).setText(toolName[i]);
            inventoryPanel.add(tools.get(i));
        }
        for(int i= 0; i< 5; i++)
        {
            Equip.add(new Button("Equip"));
            Equip.get(i).setFont(smallFont);
            Equip.get(i).setBackground(Color.blue);
            Equip.get(i).setForeground(Color.white);
            Equip.get(i).putClientProperty("index", i);
            inventoryPanel.add(Equip.get(i));
            Equip.get(i).addActionListener(action);
        }

        botPanel.add(inventoryPanel,BorderLayout.CENTER);
        update();
    }
    /**
     * initializes the buttons which is have specific commands that a player
     * may choose to do
     */
    public void ButtonChoice()
    {
          //button panel
        //  botPanel.setLayout(new BorderLayout());
        String[] buttonName = {"Equip", "Sleep", "Rank Up", "Exit"};
        ActionListener[] temp = {choice1, choice2, choice3, choice4};
          for(int i = 0; i<4; i++){
            choices.set(i,new Button(buttonName[i]));
            choices.get(i).setBackground(Color.black);
            choices.get(i).setForeground(Color.white);
            choices.get(i).setFont(normalFont);
            choices.get(i).putClientProperty("index",i);
            choices.get(i).addActionListener(temp[i]);
          }
          update();
    }
    /**
     * initialize the buttons representing the tiles of the farm
     * @param interact  action listener that gives the command on what will happen
     *   when the tile is selected
     */
    public void initializeFarm(ActionListener interact)
    {
        for(int i =0; i< 5; i++)
        {
            buttonTiles.add(new ArrayList<Button>());
           farmPanel.setSize(250,400);
            
            for(int j =0 ; j<10;j++)
            {
                buttonTiles.get(i).add(new Button());
                buttonTiles.get(i).get(j).setForeground(Color.white);
                buttonTiles.get(i).get(j).setFont(buttonFont);
                buttonTiles.get(i).get(j).addActionListener(interact);
                buttonTiles.get(i).get(j).putClientProperty("row", i);
                buttonTiles.get(i).get(j).putClientProperty("col", j);
                buttonTiles.get(i).get(j).setSize(50,50);
            }
        }
        farmPanel.revalidate();
        farmPanel.repaint();
    }
/**
 * 
 * @param isPlowed   true if the tile is plowed, false otherwise
 * @param row    row of the tile
 * @param column   column of the tile
 */
    public void showEmptyTile(boolean isPlowed, int row, int column)
    {
       
        if(isPlowed)
        {
            buttonTiles.get(row).get(column).setBackground(Color.orange);
            buttonTiles.get(row).get(column).setText("plowed");
        }else{
            buttonTiles.get(row).get(column).setBackground(Color.yellow);
            buttonTiles.get(row).get(column).setText("unplowed");
        }
            
         buttonTiles.get(row).get(column).setFont(buttonFont);
         
        farmPanel.revalidate();
        farmPanel.repaint();
    }
    /**
     * 
     * @param type  type of plant
     * @param nRow  row of the tile containing the plant
     * @param nCol   column of the tile contianing the plant
     */
    public void showPlant(int type, int nRow, int nCol,boolean isMature)
    {
        if(isMature)
            buttonTiles.get(nRow).get(nCol).setBackground(Color.magenta);
        else
             buttonTiles.get(nRow).get(nCol).setBackground(Color.green);
        buttonTiles.get(nRow).get(nCol).setForeground(Color.black);
        buttonTiles.get(nRow).get(nCol).setFont(buttonFont);
        switch(type)
        {
            case 0: buttonTiles.get(nRow).get(nCol).setText("Turnip"); break;
            case 1: buttonTiles.get(nRow).get(nCol).setText("Carrot"); break;
            case 2: buttonTiles.get(nRow).get(nCol).setText("Potato"); break;
            case 3: buttonTiles.get(nRow).get(nCol).setText("Rose"); break;
            case 4: buttonTiles.get(nRow).get(nCol).setText("Tulips"); break;
            case 5: buttonTiles.get(nRow).get(nCol).setText("Sunflower"); break;
            case 6: buttonTiles.get(nRow).get(nCol).setText("Mango"); break;
            case 7: buttonTiles.get(nRow).get(nCol).setText("Apple"); break;
        }
        farmPanel.revalidate();
        farmPanel.repaint();
    }
    /**
     * 
     * @param type this is true  if the tile contains a rock, false for a withered plant
     * @param nRow  this is the row of the tile 
     * @param nCol  this is the col of the tile
     */
    public void showObstacle(boolean type, int nRow, int nCol)
    { 
        buttonTiles.get(nRow).get(nCol).setBackground(Color.gray);
  
        if(type) //rock = true
            buttonTiles.get(nRow).get(nCol).setText("Rock");
        else
            buttonTiles.get(nRow).get(nCol).setText("Withered");

        farmPanel.revalidate();
        farmPanel.repaint();
    }
/**
 * This method handles the panel for displaying what a player
 * may choose to do with a tile like plant seed, use tool, view details, or harvest
 * @param row  - the row of the tile interacted with
 * @param col  - column of the selected tile
 * @param n  - number of commands a player can choose from depending
 *              on the tile's state
 */
    public void interactTile(int row, int  col,int start, int end)
    {
        tilePanel.removeAll();
        tilePanel.setLayout(new GridLayout(1,end));
        tilePanel.setBackground(Color.black);
        tilePanel.setForeground(Color.white);
        botPanel.removeAll();
        String[] buttonNames = {"Plant Seed", "Use tool", "Details", "Harvest"};
        
        for(int i=start;i<end;i++)
        {
            interactTile.set(i,new Button(buttonNames[i]));
            interactTile.get(i).setBackground(Color.black);
            interactTile.get(i).setForeground(Color.white);
            interactTile.get(i).setFont(normalFont);
            interactTile.get(i).putClientProperty("row", row);
            interactTile.get(i).putClientProperty("col",col);
            tilePanel.add(interactTile.get(i));
        }
        
        interactTile.get(0).addActionListener(intTileListen1);
        interactTile.get(1).addActionListener(intTileListen2);
        interactTile.get(2).addActionListener(intTileListen3);
        interactTile.get(3).addActionListener(intTileListen4);
        botPanel.removeAll();
      //  ButtonChoice();
        botPanel.add(tilePanel);
        update();  
    }
/**
 * This method handles the gameOver screen
 */
    public void gameOver(){
        JPanel titlePnl = new JPanel(new BorderLayout());
        JLabel Over = new JLabel();
        Over.setText("Game Over");
        Over.setBackground(Color.black);
        Over.setForeground(Color.white);
        Over.setFont(titleFont);
        titlePnl.setBackground(Color.black);
        titlePnl.setForeground(Color.white);
        titlePnl.add(Over,BorderLayout.CENTER);
        window.removeAll();
        update();
        window.add(titlePnl,BorderLayout.CENTER);
        update();
    }
 

    public JFrame getWindow() {
        return window;
    }
    public JPanel getFarmPanel() {
        return farmPanel;
    }
    public Button getTileButton(int row, int col){
        return buttonTiles.get(row).get(col);
    }
    public void setStartButton(ActionListener actionListener) {
        this.startButton.addActionListener(actionListener);
    }
    public void setInteract(ActionListener interact) {
        this.interact = interact;
    }
    public void setEquip(ActionListener action){
        for(int i =0;i<Equip.size();i++)
            this.Equip.get(i).addActionListener(action);
    }
   
    public void setFeedbackLbl(String text) {
        FeedbackLbl.setText(text);
    }
    public void update() {
        this.window.revalidate();
        this.window.repaint();
    }
    public JPanel getInventoryPanel() {
        return inventoryPanel;
    }
    public JPanel getChoiceButtonPanel() {
        return choiceButtonPanel;
    }
    public JPanel getBotPanel() {
        return botPanel;
    }
    public JPanel getTilePanel() {
        return tilePanel;
    }
    public JLabel getFeedbackLbl() {
        return FeedbackLbl;
    }
    public JPanel getPlayerPanel() {
        return playerPanel;
    }
    public void setChoice1(ActionListener choice1) {
        this.choice1 = choice1;
    }
    public void setChoice2(ActionListener choice2) {
        this.choice2 = choice2;
    }
    public void setChoice3(ActionListener choice3) {
        this.choice3 = choice3;
    }
    public void setChoice4(ActionListener choice4) {
        this.choice4 = choice4;
    }
  
  /*   public void setInteractTile(ActionListener action ,int index) {
        this.interactTile.get(index).addActionListener(action);
    }*/
    public JPanel getMidPanel() {
        return midPanel;
    }
    public Button getOk() {
        return ok;
    }
    public void setIntTileListen1(ActionListener intTileListen1) {
        this.intTileListen1 = intTileListen1;
    }
    public void setIntTileListen2(ActionListener intTileListen2) {
        this.intTileListen2 = intTileListen2;
    }
    public void setIntTileListen3(ActionListener intTileListen3) {
        this.intTileListen3 = intTileListen3;
    }
    public void setIntTileListen4(ActionListener intTileListen4) {
        this.intTileListen4 = intTileListen4;
    }
    public void appendFeedbackLbl(String input){
        String temp = FeedbackLbl.getText();
        FeedbackLbl.setText(temp+input);
    }
    public JTextField getMainTextArea() {
        return mainTextArea;
    }
    public void setMainTextArea(String input) {
        this.mainTextArea.setText(input);
    }
    public Font getNormalFont() {
        return normalFont;
    }
    public Font getSmallFont() {
        return smallFont;
    }
    public ActionListener getPlantListener() {
        return plantListener;
    }
    public void setPlantListener(ActionListener plantListener) {
        this.plantListener = plantListener;
    }

    public Button getButtonTiles(int row, int col) {
        return buttonTiles.get(row).get(col);
    }
    public void setOkListener(ActionListener action) {
        this.ok.addActionListener(action);
    }
    public void setOk(Button ok) {
        this.ok = ok;
    }
    public JPanel getTopPanel() {
        return topPanel;
    }
    public JTextArea getDetailsLbl() {
        return detailsLbl;
    }
    public void setDetailsLbl(String detailsLbl) {
        this.detailsLbl.setText(detailsLbl);
    }
    public void appendDetailsLbl(String details){
        String temp = detailsLbl.getText();
        detailsLbl.setText(temp+details);
    }
}
