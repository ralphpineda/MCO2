public class TurnipSeed extends Seed {
    public TurnipSeed()
    {
        super(5,2,"Turnip",1,2,0,1,1,2,"Root Crop");
    }
}
