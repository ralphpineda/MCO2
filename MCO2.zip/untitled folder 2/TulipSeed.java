public class TulipSeed extends Seed {
    public TulipSeed(){
        super(10,2,"Tulips",2,3,0,1,1,1,"Root Crop");

    }
    
}
