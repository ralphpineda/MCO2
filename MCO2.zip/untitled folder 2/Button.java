
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;

public class Button extends JButton {


        public Button() {
            super();
            this.setContentAreaFilled(false);
            this.setBorderPainted(false);
            this.setOpaque(false);
        }
        public Button(String text) {
            
            super(text);
            this.setContentAreaFilled(false);
            this.setBorderPainted(false);
            this.setOpaque(false);
        }


        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            RenderingHints hints = new RenderingHints(
                    RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON
            );
            g2d.setRenderingHints(hints);
            g2d.setColor(getBackground());
            g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 15, 15));
            g2d.setColor(getForeground());
            super.paintComponent(g2d);
            g2d.dispose();
        }
    }