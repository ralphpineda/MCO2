public class PotatoSeed extends Seed {
    public PotatoSeed(){
        super(5,5,"Potato",3,4,1,2,1,10,"Root Crop");

    }
}
