public class AppleSeed extends Seed{
    public AppleSeed(){
        super(200,10,"Apple",7,7,5,5,10,15,"Fruit Tree");

    }
    
}
