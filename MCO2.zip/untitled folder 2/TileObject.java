/**
 * This class include the obstacles that occupy the tiles in the farm which mmust be cleared off
 * before being able to  plow the tile.
 */
public class TileObject {
    private String sName;
    private String sToolRequired;

    public TileObject(String sName, String sToolRequired)
    {
        this.sName = sName;
        this.sToolRequired = sToolRequired;
    }
    
    public TileObject(TileObject obstacle)
    {
        this.sName = obstacle.getsName();
        this.sToolRequired =  obstacle.getsToolRequired();
    }
    /**
     * 
     * @return the name that specifies the type of this TileObject
     */
    public String getsName() {
        return sName;
    }
    /**
     * 
     * @return the tool required to clear this TileObject in a  tile
     */
    public String getsToolRequired() {
        return sToolRequired;
    }
    /**
     * 
     * @return the cost of clearing this object from a tile
     */


}
