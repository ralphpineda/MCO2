public class Rose extends Product {
    public Rose(){
        super("Rose", 5, (float)2.5, "Flower");
    }
}
