public class Mango extends Product {
    public Mango(){
        super("Mango", 8, (float)25, "Tree");
    }
}
