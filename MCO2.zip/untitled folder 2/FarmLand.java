import java.util.ArrayList;
import java.util.Random;

/**
 * This class refers to the whole farmLand which is composed of 10 * 5 tiles
 * source for 2d ArrayList : https://stackoverflow.com/questions/10866205/two-dimensional-array-list 
 */
public class FarmLand {
    private ArrayList<ArrayList<Tiles>> tilesList;
    private int nTilesRow, nTilesCol;
    private int nObstacleMin = 10, nObstacleMax = 30;

    /**
     * 
     * @param nTilesRow is the number of rows of tiles the farm will have
     * @param nTilesCol is the number of columns of tiles the farm will have
     */
    public FarmLand(int nTilesRow, int nTilesCol)
    {
        this.nTilesCol = nTilesCol;
        this.nTilesRow = nTilesRow;
        tilesList = new ArrayList<ArrayList<Tiles>>();
  
        this.generateTiles(0); // This is for generating row X column tileset
        tilesList.add(new ArrayList<Tiles>());
        tilesList.get(0).add(new Tiles());
    }
    /**
     * This method will randomly place obstacles (rock) to atleast 10 tiles and a max of 30 tiles
     * @param nCount is the current number of tiles which contain an obstacle (rock)
     */
    private void generateTiles(int nCount) // will be used when farm contains more than one tile and when rocks are considered
    {
        Random rand = new Random();
        int upperBound = 100;
      
        
        for(int i =0; i<nTilesRow; i++)
        {
            tilesList.add(new ArrayList<Tiles>());
            for(int j =0; j<nTilesCol;j++)
            {
                if(rand.nextInt(upperBound) %2 ==0 && nCount < nObstacleMax)
                {
                    tilesList.get(i).add(new Tiles(new Rocks()));
                    nCount ++;
                }else
                    tilesList.get(i).add(new Tiles());
            }
        }
        while(nCount < nObstacleMin)
            nCount = generateRocks(nCount); 

       // System.out.println("nCount = " + nCount);    I was checking if the distribution of rocks is indeed random
    }
/**
 * This method generates rocks on random tiles
 * @param nCount  the number of tiles that already contain a rock
 * @return  the numeber of tiles that contain a rock at the end of this method
 */
    private int generateRocks(int nCount)
    {
        Random rand = new Random();
        int upperBound = 100;

        for(int i =0; i<nTilesRow; i++)
        {
            for(int j =0; j<nTilesCol;j++)
            {
                if(rand.nextInt(upperBound) %2 ==0 && nCount < nObstacleMax && getTile(i,j).getIsEmpty()==true)
                {
                    getTile(i,j).addObstacle(new Rocks());
                        nCount ++;
                }
            }
        }
        return nCount;
    }
/**
 * This method checks if the neighboring tiles of a specified tile is empty
 * @param x  row of the specified tile
 * @param y  column of the specified tile
 * @return  true if all neighbor tiles are empty, false otherwise
 */
    public boolean checkNeighbor(int x, int y)
    {
        boolean isGood = true;
        if(x==0||x== nTilesRow-1||y==0||y==nTilesCol-1){ //check if tile is on the far side of the farm
            isGood = false;
    }else 
        for(int i = x-1;i<x+1;i++ ) //check if adjacent tiles are occupied
             for(int j = y-1;j<y+1;j++)
                if(getTile(i,j).getIsEmpty() == false)
                    isGood = false;
        return isGood;
    }
/**
 * This method handles the planting of seed.
 * @param input  The name of the seed to be planted
 * @param shop  the player's financial object
 * @param row  row of the tile to be planted on
 * @param col  column of the tile to be planted on
 * @return  true if planted successfully, false otherwise
 */
    public boolean plantSeed(String input,Market shop, int row, int col)
    {
        Seed seed;
        boolean isPlanted = false;
        Tiles tile = getTile(row, col);
        if(tile.getIsPlowed() && tile.getIsEmpty())
        {
            int nIndex = GameCommands.commandChoice(input.toLowerCase(), GameCommands.getsAvailableSeeds());
            switch(nIndex)
            {
                case 0: seed = new TurnipSeed(); break;
                case 1: seed = new CarrotSeed(); break;
                case 2: seed = new PotatoSeed(); break;
                case 3: seed = new RoseSeed(); break;
                case 4: seed = new TulipSeed(); break;
                case 5: seed = new SunflowerSeed(); break;
                case 6: seed = new MangoSeed(); break;
                case 7: seed = new AppleSeed(); break;
                default: seed = new TurnipSeed();
            }
            if(seed.getsCropType()=="Fruit Tree")
            {
                if(checkNeighbor(row,col))
                {
                    if(shop.buySeeds(seed))
                    {
                        isPlanted = true;
                        tile.setSeed(seed);        
                    }  
                }else
                    System.out.println("Surrounding tiles must be empty.");
            }else if(shop.buySeeds(seed))
            {
                isPlanted = true;
                tile.setSeed(seed);  
            }
        }else
            System.out.println("You must plow this tile first.");
        return isPlanted;
    }
    /**
     * Checks if all tiles have withered crops
     * @return true if all tiles contain withered crops
     */
    public boolean allWithered(){
        int nCount =0;
        for(int i =0; i< nTilesRow;i++)
            for(int j=0;j<nTilesCol;j++)
                if(tilesList.get(i).get(j).getHasObstacle())
                    if(tilesList.get(i).get(j).getObstacle().getsName()=="Withered Plant")
                        nCount ++;
        if(nCount == nTilesRow*nTilesCol)
            return true;
        return false;
    }
/**
 * Method for checking if there are active crops
 * @return true if no active crops
 */
    public boolean noActiveCrops(){
        int nCount =0;
        for(int i=0;i<nTilesRow;i++)
            for(int j=0;j<nTilesCol;j++)
                if(tilesList.get(i).get(j).getHasPlant())
                    nCount++;
        if(nCount ==0)
            return true;
        else
            return false;
    }
/**
 * This method updates the time for each tile  exists in the farm
 */
    public void nextDay()
    {
        for(int i =0; i<nTilesRow;i++)
            for(int j = 0; j<nTilesCol;j++)
                if(getTile(i, j).getHasPlant())
                    getTile(i, j).nextDay();
    }
/**
 * Get the number of columns in the farm
 * @return  the number of columns
 */
    public int getnTilesCol() {
        return nTilesCol;
    }
    /**
     * Get the number of rows in the farm
     * @return  the number of rows
     */
    public int getnTilesRow() {
        return nTilesRow;
    }
/**
 * This method returns the tile specified by the given row and column
 * @param nRow  the row of the tile to be returned
 * @param nCol  the colummn of the tile to be returned
 * @return  the tile specified by the row and column
 */
    public Tiles getTile(int nRow, int nCol){
        return this.tilesList.get(nRow).get(nCol);
    }
}
