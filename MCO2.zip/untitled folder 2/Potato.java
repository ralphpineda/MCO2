public class Potato extends Product {
    public Potato(){
        super("Potato", 3, (float) 12.5, "Root Crop");
    }
    
}
