
public class Fertilizer extends Tools{
    public Fertilizer()
    {
        super("Fertilizer",(float)10,(float)4);
    }
}
