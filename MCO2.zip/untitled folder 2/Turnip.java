public class Turnip extends Product {
    public Turnip()
    {
        super("Turnip", 6, 5, "Root Crop");
    }
}
