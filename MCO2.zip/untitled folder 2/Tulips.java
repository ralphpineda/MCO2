public class Tulips extends Product{
    public Tulips(){
        super("Tulips", 9, (float)5, "Flower");
    }
}
