
/**
 * This class refers to the plot of land which may contain an obstacle (rock or withered plant), or a seed. It must be plowed
 * before being able to contain a seed. It will also have a boolean attribute of isEmpty to prevent it from containing a seed
 * when it already contains a rock.
 */
public class Tiles {
    private TileObject obstacle;
    private Seed seed;
    private boolean isPlowed;
    private boolean isEmpty;
    private boolean hasObstacle;
    private boolean hasPlant;

    /**
     * This constructor method is for instantiating an empty tile.
     */
    public Tiles()
    {
        isPlowed = false;
        isEmpty = true;
        hasObstacle = false;
        hasPlant = false;
    }
    /**
     * This constructor method is for instantiating a tile containing an obstacle.
     * @param obstacle
     */
    public Tiles(TileObject obstacle)
    {
        isPlowed =  false;
        isEmpty = false;
        hasObstacle = true;
        hasPlant = false;
        this.obstacle = new Rocks();
    }
    /**
     * This method handles all possible interactions with a tile using a tool.
     * @param player this is the player interacting with the tile
     */
    public int interactTool(MyPlayer player)
    {
        int value = 0;;
      //  int nIndex = GameCommands.commandChoice(player.getsItemEquipped().getsName().toLowerCase(), GameCommands.getsAvailableTools());
        if(isEmpty == false)
        {
            if(hasObstacle)
            {
             //  interactObstacle(player, nIndex);
               value =  0;
            }else if(hasPlant)
            {
               // interactPlant(player, nIndex);
                value = 1;
            }
        }else // interactEmpty(player, nIndex);
            value = 2;
        return value;
    }
    /**
     * This method handles interaction with an empty tile
     * @param player  this is the player interacting with the tile
     * @param nIndex  this is identifies the item equipped by the player
     */
    public int interactEmpty(MyPlayer player, int nIndex)
    {
        int value = 0;
        if(isPlowed == false)
            {
                switch(nIndex)
                {
                    case 0: if(player.useTool())
                            {
                                isPlowed = true;
                                value  = 0;
                               // System.out.println("Tile is plowed successfully.");
                            }else value =1; break;
                    case 4: if(player.useTool()) value = 2; else value =3;break;
                    default: value = 4;//System.out.println("You need to equip the plowing tool."); 
                }            
            }else
              value = 5;//  System.out.println("Tile is already plowed."); 
              return value;
    }
    /**
     * This method handles interacting with a tile that has an obstacle.
     * @param player  this is the player interacting with the tile
     * @param nIndex  this is the index of the tool equipped from a player's inventory
     */
    public int interactObstacle(MyPlayer player, int nIndex)
    {
        int value = 0;
        if(obstacle.getsName()=="Rock")
        {
            switch(nIndex)
            {
                case 3:if(player.useTool()) //pickaxe is equipped
                        {
                            hasObstacle = false;
                            isEmpty = true; 
                            isPlowed = false;
                            obstacle = null;
                            value = 0;
                        }value = 1;break;
                case 4:if(player.useTool())
                            value = 2;//System.out.println("Action as no effect.");break; shovel is equipped   
                        else value =3;      
                default : value = 4;//System.out.println("Error: Invalid Interaction");
            }
        }else if(obstacle.getsName()=="Withered Plant");
        {
            if(nIndex ==4)
            {
                if(player.useTool())
                {
                    hasObstacle = false;
                    isEmpty = true;
                    isPlowed = false;
                    obstacle = null;
                    value = 5;//System.out.println("Withered plant removed.");
                }else value =6;
            }else
                 value = 7;//System.out.println(("Error: Invalid Interaction"));
        }
        return value;
    }
    /**
     * This method handles interacting with a tile which contains a plant
     * @param player  this is thhe player interacting with the tile
     * @param nIndex  this is the identifies the player's equipped item
     */
    public int interactPlant(MyPlayer player, int nIndex)
    {
        int value;
        switch(nIndex)
        {
            case 1: if(player.useTool()) // watering can is equipped
                    {
                        seed.waterPlant();
                        value = 0;
                    }else value = 1;
                         break;
            case 2: if(player.useTool()) // fertilizer is equipped
                    {
                        seed.fertilizePlant();
                        value = 2;
                    }else value = 3;
                         break;
            case 4: if(player.useTool()) value =4;
                    else value = 5; break; //shovel is equipped
            default: value = 6; //System.out.println("Error: Invalid Interaction");
        }
        return value;
    }

    public void harvest()
    {
        isPlowed = false;
        hasPlant = false;
        isEmpty = true;
        seed = null;
    }
    public void nextDay()
    {
        if(hasPlant)
        {
            seed.ageTimer();
            if(seed.getIsWithered())
            {
                hasPlant = false;
                obstacle =  new Withered();
                hasObstacle = true;
                System.out.println("Plant has withered\n");
            }
        }
    }
/**
 * This method adds an obstacle (rock/withered plant) to the tile.
 * @param osbtacle Can be a rock or a withered plant, both of which needs to be cleared 
 *                  off before being able to use the tile productively.
 * @return True if the TileObject is added successfully, false otherwise which occurs if 
 *          the tile is noto empty
 */
    public boolean addObstacle(TileObject osbtacle)
    {
        if(isEmpty == true)
        {
            //aadd random rocks/
            obstacle = new TileObject(obstacle);
            isEmpty =false;
            hasObstacle = true;
        }
        return  !isEmpty;
    }

    public boolean getIsEmpty()
    {
        return isEmpty;
    }
    public TileObject getObstacle() {
        return obstacle;
    }
    public Seed getSeed() {
        return seed;
    }
    public boolean getHasObstacle(){
        return hasObstacle;
    }
    public boolean getHasPlant(){
        return hasPlant;
    }
    public boolean getIsPlowed(){
        return isPlowed;
    }
    public void setSeed(Seed seed) {
        this.seed = seed;
        isEmpty = false;
        hasPlant = true;
    }
}
