/**
 * This class represents the time of the game world. It includes the date, and the hour and minutes. The minutes 
 * will be counted by multiples of 5.
 */
public class Time {
    private int nDay, nMonth, nYear, nHour, nMin;

    public Time()
    {
        this.nDay = 1;
        this.nMonth = 1;
        this.nYear = 1;
        this.nHour = 0;
        this.nMin = 0;
    }
    /**
     * This method will end the current game day and move on to the next game day.
     */
    public void nextDay()
    {
        this.nDay +=1;
        this.updateDay();
    }
    /**
     * This method will reset the day number back to 1 at the start of a new month
     */
    public void updateDay()
    {
        if((this.nMonth<8 && this.nMonth%2==1)||(this.nMonth>7 && this.nMonth%2 ==0))
        {
            if(this.nDay >31)
            {
                this.nDay =1;
                this.nMonth +=1;
                this.updateMonth();
            }
        }else if(this.nMonth != 2)
        {
            if(this.nDay >30)
            {
                this.nDay =1;
                this.nMonth +=1;
                this.updateMonth();
            }
        }else
        {
            if(this.isLeapYear())
            {
                if(this.nDay>29)
                {
                    this.nDay =1;
                    this.nMonth +=1;
                    this.updateMonth();
                }
            }else
            {
                if(this.nDay >28)
                {
                    this.nDay =1;
                    this.nMonth +=1;
                    this.updateMonth();
                }
            }
        }
    }
/**
 * This method will reset the month back to 1 at the start of every new year.
 */
    public void updateMonth()
    {
        if(this.nMonth >12)
        {
            this.nMonth = 1;
            this.nYear +=1;
        }
    }
/**
 * This method will increment the hour by 1 and rests back to 0 at the start of a new day
 */
    public void updateHour()
    {
        this.nHour +=1;
        if(this.nHour >23)
        {
            this.nHour =0;
            this.nextDay();
        }
    }
/**
 * This method increments the game minutes by multiples of 5 and goes back to 0 at the start of a new hour.
 */
    public void updateMin()
    {
        this.nMin +=5;
        if(this.nMin ==60)
        {
            this.nMin = 0;
            this.updateHour();
        }
    }
    /**
     * This method will check if the current game Year is a leap year.
     * @return true if the current year is a leap year, false otherwise.
     */
    public boolean isLeapYear()
    {
        if(this. nYear %4 ==0)
            return true;
        else
            return false;
    }

    public int getnDay() {
        return nDay;
    }
    public int getnHour() {
        return nHour;
    }
    public int getnMin() {
        return nMin;
    }
    public int getnMonth() {
        return nMonth;
    }
    public int getnYear() {
        return nYear;
    }
    
}
