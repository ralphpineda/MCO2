public class Plow extends Tools {

    public Plow()
    {
        super("Plow",0, (float)0.5);
    }
}
