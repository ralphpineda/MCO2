/**
 * this class inherits from the class TileObject as TileObjects occuppy a tile and must be cleared off before the player is able to 
 * access the tile in a productive way. Every TileObject has a specific tool required to clear it, the rocks TileObject require a pickaxe.
 */
public class Rocks extends TileObject{
    public Rocks()
    {
        super("Rock", "Pickaxe");
    }
    
}
