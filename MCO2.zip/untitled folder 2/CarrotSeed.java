public class CarrotSeed extends Seed{
    public CarrotSeed(){
        super(10,3,"Carrot",1,2,0,1,1,2,"Root Crop");

    }
}
