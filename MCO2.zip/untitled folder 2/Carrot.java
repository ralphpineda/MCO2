public class Carrot extends Product{
    public Carrot(){
        super("Carrot", 9, (float) 7.5, "Root Crop");
    }
    
}
