public class Shovel extends Tools{
    public Shovel()
    {
        super("Shovel", (float)7,(float)2);
    }
}
