import java.util.ArrayList;

/**
 * This class handles the player's economic activities. The player's object coins is stored in this class because 
 * the existence of object coins only makes sense in the context of a market.
 */
public class Market {
    private float ObjCoin;
    public Market()
    {
        ObjCoin = 100;
    }
/**
 * This method deducts the cost of using the given tool from the player's object coin
 * @param tool  this is the tool to be used by the player
 * @return  true if player has enough object coins to use the tool, false if not 
 */
   public boolean payToolCost(Tools tool)
   {
        boolean isPaid = false;
        if(tool.getfCost()<=ObjCoin)
        {
            ObjCoin -= tool.getfCost();
            isPaid = true;
            new GameView().displayObjExp(tool.getfCost()*-1, tool.getfExpGained());
        }
        return isPaid;
   }
/**
 * This method deducts the cost of buying the seed to the player's object coins
 * @param seed  this is the seed to be planted by the player
 * @return  true if the player has enough funds to buy the seed, false otherwise
 */
    public boolean buySeeds(Seed seed)
    {
        boolean isBought = false;
        if(ObjCoin >= seed.getfCost()&&seed!= null)
        {
            System.out.println(seed.getsName()+" has been purchased for "+ seed.getfCost()+" object coins.");
            ObjCoin -= seed.getfCost();
            isBought = true;
        }else if(ObjCoin< seed.getfCost()&&seed!=null)
            System.out.println("You lack the necessary funds to purchase a "+ seed.getsName()+".");
        return isBought;
    }
   /**
    * This method handles the selling of products by computing for the total pricec and 
        updating the player's object coins
    * @param productList  this is the list of products to be sold
    * @param sfarmRank  this is the rank of the farmer so the respective bonuses may apply
    * @param nWater  this is the number of times the plant had been watered to apply the water bonus
    * @param nFertil  this is the number of times the plant had been fertilized to apply the fertilizer bonus
    */
    public void sellProduce(ArrayList<Product> productList, String sfarmRank, int nWater, int nFertil)
    {
        int nRank = GameCommands.commandChoice(sfarmRank, GameCommands.getsFarmerTypes());
        float fHarvest = productList.size() * (productList.get(0).getfPrice() + GameCommands.power(2,nRank-1));
        float fWater = fHarvest *(float) 0.2 * (nWater-1);
        float fFertil = fHarvest * (float)0.5 * nFertil;
        float fTotal = fHarvest + fFertil + fWater;
        if(productList.get(0).getsCropType() == "Flower")
            fTotal *= 1.1;
        System.out.println("Successfully sold  "+productList.size()+" "+ productList.get(0).getsName());
        new GameView().displayObjExp(fTotal, productList.get(0).getfExp()*productList.size());
        ObjCoin += fTotal;
    }
    /**
     * This is the getter method for Market.ObjCoin. This allows the player to view his current funds.
     * @return  the player's object coins
     */
    public float getObjCoin() {
        return ObjCoin;
    }
    /**
     * This is the setter method for Market.ObjCoin. This allows other methods to deduce/add a value
     * to the player's current funds
     * @param objCoin  the player's object coins
     */
 
}
