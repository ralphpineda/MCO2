
public class WateringCan extends Tools{
    public WateringCan()
    {
        super("WateringCan",0,(float)0.5);
    }
}
