
public class Pickaxe extends Tools{
    public Pickaxe()
    {
        super("Pickaxe",(float)50,(float)15);
    }
}
