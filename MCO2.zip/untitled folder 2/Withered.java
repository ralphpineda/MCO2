public class Withered extends TileObject {
    public  Withered()
    {
        super("Withered Plant", "Shovel");
    }
}
