
import java.util.ArrayList;
import java.util.Scanner;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * This is the controller class for this project. It handles player input and the performs the necessary 
 * instructions according to the player input
 */
public class GameController {
    Scanner sc = new Scanner(System.in);
    private FarmLand farm;
    private MyPlayer player;
    private Time gameTime; 
    private GamePanel panel; 

    /**
     * Constructor for GameControler
     * @param view
     * @param panel
     */
    public GameController(GamePanel panel)
    {
        farm = new FarmLand(5, 10);
        gameTime = new  Time();
        player = new MyPlayer("Ralph");
        this.panel = panel;
       
        initializeChoiceListeners();
        initializeTileListener();
        
        panel.setStartButton( new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
            setPlayerDetails();
             panel.createGameScreen();
             showFarm();
             panel.update();
            }
        });
        panel.setPlantListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent f){
                update();
                String input = panel.getMainTextArea().getText();
                int index  = GameCommands.commandChoice(input, GameCommands.getsAvailableSeeds());
                Button temp = (Button)f.getSource();
                int row =(int) temp.getClientProperty("row");
                int col =(int) temp.getClientProperty("col");
                if(farm.plantSeed(GameCommands.getsAvailableSeeds().get(index), player.getShop(), row, col))
                    panel.setFeedbackLbl("Success");
                else
                    panel.setFeedbackLbl("Failed");

            initializeTileListener();
            panel.getFarmPanel().removeAll();
            panel.getChoiceButtonPanel().removeAll();
            panel.initializeChoiceButtonPanel();
               // panel.getPromptPanel().removeAll();
          //     panel.getMidPanel().remove(panel.getTextPanel());
           //    panel.getTextPanel().removeAll();
             //  panel.initializeTextPanel();
               panel.getBotPanel().removeAll();
                panel.getBotPanel().add(panel.getFeedbackLbl());
                panel.getBotPanel().add(panel.getChoiceButtonPanel());
            update();
            }
        });
            panel.setEquip(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                //To Do
                Button temp = (Button) e.getSource();
                int index = (int) temp.getClientProperty("index");
                String[] tool = {"Plow", "Watering Can", "Fertilizer", "Pickaxe", "Shovel"};
                player.equipItem(tool[index]);
                setPlayerDetails();
                panel.getBotPanel().removeAll();
                panel.getBotPanel().add(panel.getChoiceButtonPanel());
               update();                    
            }});
            panel.setInteract(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent d){
                Button temp = (Button)d.getSource();
                int row = (int)temp.getClientProperty("row");
                int col = (int)temp.getClientProperty("col");
                if(farm.getTile(row, col).getIsEmpty())
                    panel.interactTile(row, col,0, 2);
                else if(farm.getTile(row,col).getHasObstacle())
                    panel.interactTile(row,col,1,3);
                else if(farm.getTile(row, col).getHasPlant())
                    if(farm.getTile(row, col).getSeed().getIsMature())
                        panel.interactTile(row, col, 1,4);
                    else 
                        panel.interactTile(row, col, 1, 3);

        }});


        //this is the action listener present in each tile in the farm
        
    }
    public void setPlayerDetails()
    {
        ArrayList<String> details = new ArrayList<String>();
        details.add(player.getsName());
        details.add(String.valueOf(player.getShop().getObjCoin()));
        details.add(player.getsItemEquipped().getsName());
        details.add(String.valueOf(player.getnLevel()));
        details.add(String.valueOf(player.getfExp()));
        details.add(player.getsType());
        details.add(String.valueOf(String.valueOf(gameTime.getnMonth())+":"+String.valueOf(gameTime.getnDay())+":"+String.valueOf(gameTime.getnYear())));
        panel.initializeplayerPanel(details);
    }
    public void update()
    {
        setPlayerDetails();
        panel.getTopPanel().removeAll();
        panel.getTopPanel().add(panel.getPlayerPanel());
        panel.getFarmPanel().removeAll();
       showFarm();
      
       panel.update();
       
    }
    public void reset(){
        panel.getWindow().removeAll();
        panel.gameOver();
    }
    /**
     * This method shows the 5*10 tiles farm
     */
    public void showFarm()
    {
        for(int i = 0; i<5;i++)
        {
            for(int j=0;j<10;j++)
            {
                if(farm.getTile(i, j).getIsEmpty())
                {
                    panel.showEmptyTile(farm.getTile(i, j).getIsPlowed(), i, j);
                }else if(farm.getTile(i, j).getHasPlant()){
                 panel.showPlant(GameCommands.commandChoice(farm.getTile(i, j).getSeed().getsName(), GameCommands.getsAvailableSeeds()), i, j,farm.getTile(i,j).getSeed().getIsMature());
                }
                else if(farm.getTile(i,j).getHasObstacle())
                {
                    panel.showObstacle(farm.getTile(i, j).getObstacle().getsName()=="Rock", i, j);
                }
                panel.getFarmPanel().add(panel.getButtonTiles(i, j));
            }
        }
    }
    /**
     * This method sets the action listeners for the buttons : equip, rankup, netx day, exit
     */
    public void initializeChoiceListeners(){
        panel.setChoice1(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                panel.displayInventory(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        //To Do
                        Button temp = (Button) e.getSource();
                        int index = (int) temp.getClientProperty("index");
                        String[] tool = {"Plow", "Watering Can", "Fertilizer", "Pickaxe", "Shovel"};
                        player.equipItem(tool[index]);
                        setPlayerDetails();
                        panel.getBotPanel().removeAll();
                        panel.getBotPanel().add(panel.getChoiceButtonPanel());
                       update();
                        }
                    });
                update();
                }
        });
        panel.setChoice2(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                  advanceDay();
                  update();
                }
        });
        panel.setChoice3(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
               player.registerType();
               update();
                }
        });
        panel.setChoice4(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
            
                reset();
                update();
                }
        });
      }
    /*This method handles interaction with a tile */
    public void initializeTileListener(){
        //plant seed
        panel.setIntTileListen1(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
               
                Button ok = (Button) e.getSource();
                ok.setText("OK");
                ok.addActionListener(panel.getPlantListener());
                update();
                //panel.getBotPanel().removeAll();
                panel.setMainTextArea("Enter seed name.");
                panel.setOk(ok);
                panel.getBotPanel().add(panel.getMainTextArea());
                panel.getBotPanel().add(ok);
                
                panel.update();
            }
        });
        //use tool interactions
        panel.setIntTileListen2(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent g){
                Button ok = (Button) g.getSource();
                
                int row = (int)ok.getClientProperty("row");
                int col =(int) ok.getClientProperty("col");
                int nIndex = GameCommands.commandChoice(player.getsItemEquipped().getsName().toLowerCase(), GameCommands.getsAvailableTools());
                int tileCase = farm.getTile(row, col).interactTool(player);
                int outcome;
                panel.getBotPanel().removeAll();
                switch(tileCase){
                    case 0: outcome = farm.getTile(row, col).interactObstacle(player, nIndex);
                            switch(outcome)
                            {
                                case 0: panel.getFeedbackLbl().setText("Rock is removed successfully");  break ;
                                case 1: panel.getFeedbackLbl().setText("Not enough funds to use this tool"); break;
                                case 2: panel.getFeedbackLbl().setText("Action has no effect");  break;
                                case 3: panel.getFeedbackLbl().setText("Error : Invalid Interaction");  break;
                                case 5:panel.getFeedbackLbl().setText("Withered Plant is removed"); break;
                                case 6:panel.getFeedbackLbl().setText("Not enough funds to use this tool"); break;
                                case 7:panel.getFeedbackLbl().setText("Error : Invalid Interaction");  break;
                            } break;          
                    case 1: outcome = farm.getTile(row, col).interactPlant(player, nIndex);
                            if(outcome %2==1)
                               panel.setMainTextArea("Not enough funds to use this tool");
                            switch(outcome)
                            {
                                case 0: panel.setFeedbackLbl("Plant is watered");break;
                                case 2:panel.setFeedbackLbl("Plant is fertilized"); break;
                                case 4: panel.setFeedbackLbl("Action has no effect"); break;
                                case 6: panel.setFeedbackLbl("Error : Invalid Interaction"); break;
                            }break;
                     case 2: outcome = farm.getTile(row, col).interactEmpty(player, nIndex);
                            switch(outcome)
                            {
                                case 0: panel.setFeedbackLbl("Tile is plowed successfully."); break;
                                case 1: panel.setFeedbackLbl("Not enough funds to use this tool."); break;
                                case 2: panel.setFeedbackLbl("Action has no effect."); break;
                                case 3: panel.setFeedbackLbl("Not enough funds to use this tool."); break;
                                case 4: panel.setFeedbackLbl("You need to equip the plowing tool."); break;
                                case 5: panel.setFeedbackLbl("Tile is already plowed.");break;
                            }break;
                }
                
                update();
                panel.getBotPanel().add(panel.getFeedbackLbl(), BorderLayout.LINE_START);
                panel.getBotPanel().add(panel.getChoiceButtonPanel(),BorderLayout.CENTER);
                panel.update(); 
            }
            });
            //view details
            panel.setIntTileListen3(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent f){
                    Button ok = (Button) f.getSource();
                    int row = (int)ok.getClientProperty("row");
                    int col =(int) ok.getClientProperty("col");
                    if(farm.getTile(row,col).getHasPlant())
                    {
                        panel.setDetailsLbl("This is a "+farm.getTile(row, col).getSeed().getsName());
                        panel.appendDetailsLbl("\nTimes Watered - "+farm.getTile(row, col).getSeed().getnWaterCount());
                        panel.appendDetailsLbl("\nTimes Fertilized - "+farm.getTile(row, col).getSeed().getnWaterCount());
                        panel.appendDetailsLbl("\nAge - "+farm.getTile(row, col).getSeed().getnWaterCount());
                        if(farm.getTile(row, col).getSeed().getIsMature())
                        {
                            panel.appendDetailsLbl("Ready for Harvest - \n"+farm.getTile(row, col).getSeed().getProductList().size()+" "+farm.getTile(row, col).getSeed().getProductList().get(0).getsName());
                        }
                    }else if(farm.getTile(row, col).getHasObstacle()){
                        if(farm.getTile(row,col).getObstacle().getsName()=="Rock")
                            panel.setDetailsLbl("Use pickaxe to clear this Rock");
                        else
                             panel.setDetailsLbl("Use shovel to clear this Withered Plant");
                    }
                    panel.getMidPanel().add(panel.getDetailsLbl());
                    }
                
            });
            //harvest
            panel.setIntTileListen4(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent h){
                    Button ok = (Button) h.getSource();
                    int row = (int)ok.getClientProperty("row");
                    int col =(int) ok.getClientProperty("col");
                    panel.appendFeedbackLbl(farm.getTile(row,col).getSeed().getnProductsYield()+"  "+farm.getTile(row,col).getSeed().getProductList().get(0).getsName() +"\n");
                    player.harvestProduct(farm.getTile(row, col));
                    update();
                }
            }); 
    }
    public void gameOver(){
        if(farm.allWithered()||(farm.noActiveCrops()&&player.getShop().getObjCoin()<5))
        {
            panel.gameOver();
        }
    }
    /**
     * This method applies the update in time to necessary objects. 
     */
    public void advanceDay()
    {
        gameTime.nextDay();
        farm.nextDay(); 
        setPlayerDetails();        
        panel.getFarmPanel().removeAll();
        showFarm();
        update();
        gameOver();
      //  view.displayFarm(farm, gameTime);
    }
}
