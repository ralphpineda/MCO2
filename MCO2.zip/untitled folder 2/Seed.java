import java.util.ArrayList;
import java.util.Random;
/**
 * This class refers to the seeds that can be planted on a tile. The seed requires a minimum count of being watered and fertilized, and
 * also the number of days required to pass in order forr the seed to mature into a crop that can be harvested. If the minimum count of being watered or fertilized is not met 
 * or if the seed is already matured but a day passes by without its products beinnng harvested, then the seed/crop will turn into 
 * a withered crop which is a child of TileObject.
 */
public class Seed {
    private int nHarvestTime, nAge, nWaterMin, nWaterMax, nWaterCount;
    private int nFertilMin, nFertilMax, nFertilCount, nProductsMin, nProductsMax, nProductsYield;
    private float fCost;
    private String sName, sCropType;
    private boolean  isWatered, isFertilized, isMature, isWithered;
    private ArrayList<Product> productList;
/**
 * This constructor will be used by the subcategories (child classes)
 * @param fCost  cost of the seed
 * @param nHarvestTime  number of days required for the crop to mature
 * @param sName  name of the seed
 * @param nWaterMin  minimum number of times of being watered 
 * @param nWaterMax  maximum number of times of being watered that will be counted, there will be no consequence for exceeding this limit
 * @param nFertilMin  minimum number of times of being watered 
 * @param nFertilMax  maximum number of times of being watered that will be counted, there will be no consequence for exceeding this limit
 * @param nProductsMin minimum number of products that this crop can yield
 * @param nProductsMax  maximum number of products that this crop can yield
 * @param nProductsYield the actual number of products produced by a grown seed
 * @param sCropType  the type of crop this seed belongs to
 */
    public Seed(float fCost, int nHarvestTime, String sName, int nWaterMin, int nWaterMax,
                int nFertilMin, int nFertilMax, int nProductsMin, int nProductsMax, String sCropType)
    {
        this.fCost = fCost;
        this.nHarvestTime = nHarvestTime;
        this.sName = sName;
        this.isWatered = false;
        this.isFertilized = false;
        this.isMature = false;
        this.isWithered = false;
        this.nWaterMin = nWaterMin;
        this.nWaterMax = nWaterMax;
        this.nFertilMin = nFertilMin;
        this.nFertilMax = nFertilMax;
        this.nProductsMin = nProductsMin;
        this.nProductsMax = nProductsMax;
        this.sCropType = sCropType;
        this.nAge =0;
        this.nProductsYield =0;
    }
    
/**
 * This method is called when the seed is to be watered. It updates the seed's 
 * nWaterCount and the isWatered attributes. A seed can't be watered more than once a day.
 */
    public void waterPlant()
    {
        if(isWatered == false && nWaterCount < nWaterMax)
        {
            nWaterCount++;
            isWatered = true;
            System.out.println("Watering success.");
        }else
            System.out.println("Watering served no effect.");
    }
/**
 * This method is called when the seed is to be fertilized. It updates the seed's 
 * nFertilCount and the isFertilized attributes. A seed can't be fertilized more than once a day.
 */
    public void fertilizePlant()
    {
        if(isFertilized == false && nFertilCount < nFertilMax)
        {
            nFertilCount++;
            isFertilized = true;
            System.out.println("Fertilizing success.");
        }else
            System.out.println("Fertilizer served no effect.");

    }

    /**
     * This method will age up the seed whenever the in game day passes by. It resets 
     * the seed's isWatered and isFertilized attributes so the player can water/fertilize
     * the plant again for the next day if possible. This calls matureCrop() if the plant is ready
     * to be harvested and witherCrop() if the plant is not harvested during the harvest day.
     */
    public void ageTimer()
    {
        this.nAge ++;
        isWatered = false;
        isFertilized = false;
        if(this.nAge ==this.nHarvestTime)
            this.matureCrop();
        else if(this.nAge > this.nHarvestTime)
            this.witherCrop();
    }
    /**
     * This is the method for signaling that the crop is now harvestable. This will call yieldProducts
     * to create the products when the plant is ready to be harvested. This will call witherCrop() to let
     * the plant wither when its requirements on water and fertilizer are not met before the harvest day
     */
    public void matureCrop() //return number of products
    {
        
        if(this.nWaterCount >= this.nWaterMin && this.nFertilCount >=this.nFertilMin)
        {
            this.isMature = true;
            this.productList = new ArrayList<Product>();
            yieldProducts();
        }else
            this.witherCrop();
    }
    /**
     * This is the method for producing the products associated with this seed. It generates a random
     * number  of products with different types of seeds having different limits on the maximum number of products.
     */
    public void yieldProducts()
    {
        int nIndex = GameCommands.commandChoice(sName, GameCommands.getsAvailableSeeds());
        Random rand = new Random();
        nProductsYield = rand.nextInt(nProductsMin, nProductsMax+1);
        productList = new ArrayList<Product>();
        for(int i=0;i<nProductsYield;i++)
            switch(nIndex)
            {
                case 0:  productList.add(new Turnip()); break;
                case 1:  productList.add(new Carrot()); break;
                case 2:  productList.add(new Potato()); break;
                case 3:  productList.add(new Rose()); break;
                case 4:  productList.add(new Tulips()); break;
                case 5:  productList.add(new Sunflower()); break;
                case 6:  productList.add(new Mango()); break;
                case 7:  productList.add(new Apple()); break;
                        
                default: productList.add(new Turnip());break;
            }
    }
/**
 * This method is for handling cases where the crop should now be withered. It updates isMature to false
 * and iswithered = true, and nProductsYield =0;
 */
    public void witherCrop()
    {
        isWithered=true;
        isMature = false;
        nProductsYield = 0;
    }
    /**
     * Get this seed's required minimum amount of water.
     * @return  the minimum amount of water required for the plant to produce products by harvest day
     */
    public int getnWaterMin() {
        return nWaterMin;
    }
    /**
     * Get this seed's maximum amount of water allowed. This seed's nWaterCount will no longer increment
     * once it reaches this limit.
     * @return  the maximum amount of water allowed
     */
    public int getnWaterMax() {
        return nWaterMax;
    }
    /**
     * Get this seed's current number of times watered.
     * @return  the number of times the seed has been watered
     */
    public int getnWaterCount() {
        return nWaterCount;
    }
    /**
     * Get this seed's required minimum amount of fertilizer
     * @return  the minimum amount of times this seed has to be fertilized in order to mature
     */
    public int getnFertilMin() {
        return nFertilMin;
    }
    /**
     * Get this seed's maximum amount of times to be fertilized. It will not update its nFertilCount once
     * it reaches this limit. There will be no consequencec if the player waters the seed more than the maximum.
     * @return  the maximum number of times this seed can be fertilized
     */
    public int getnFertilMax() {
        return nFertilMax;
    }
    public int getnFertilCount() {
        return nFertilCount;
    }
    public int getnProductsMin() {
        return nProductsMin;
    }
    /**
     * Get the maximum limit of products this seed can yield
     * @return  tthe maximum limit of products this seed can yield
     */
    public int getnProductsMax() {
        return nProductsMax;
    }
    /**
     * Get the cost of purchase for this seed
     * @return  the cost of purchase for this seed
     */
    public float getfCost() {
        return fCost;
    }
    /**
     * Get the type of seed of this instance
     * @return  the name of this type of seed
     */
    public String getsName() {
        return sName;
    }
    /**
     * Get the type if crop this seed belongs to
     * @return the name of the type of crop
     */
    public String getsCropType() {
        return sCropType;
    }
    /**
     * Get the list of product yielded by this seed
     * @return the list of products produced
     */
    public ArrayList<Product> getProductList() {
        return productList;
    }
    /**
     * Get the boolean value if the seed is harvestable or not
     * @return true if the plant is harvestable, false if not
     */
    public boolean getIsMature()
    {
        return isMature;
    }
    /**
     * Get the value of this instance's boolean isWithered 
     * @return true if the seed is withered, false if not
     */
    public boolean getIsWithered()
    {
        return isWithered;
    }
    /**
     * This a getter method for the number of days that tell when this seed will mature into a harvestable crop
     * @return the number of days that will dictate when this seed will mature into a product yielding crop
     */
    public int getnHarvestTime() {
        return nHarvestTime;
    }
    public int getnAge() {
        return nAge;
    }
    public int getnProductsYield() {
        return nProductsYield;
    }
 
    public void setFertilized(boolean isFertilized) {
        this.isFertilized = isFertilized;
        if(isFertilized == true && this.nFertilCount < this.nFertilMax)
            this.nFertilCount ++;
    }
    public void setWatered(boolean isWatered) {
        this.isWatered = isWatered;
        if(isWatered == true && this.nWaterCount < this.nWaterMax)
            this.nWaterCount++;
    }

}
