public class Apple extends Product{
    public Apple(){
        super("Apple", 5, (float)25, "Tree");
    }
    
}
