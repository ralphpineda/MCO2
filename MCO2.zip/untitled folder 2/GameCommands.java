import java.util.ArrayList;
/**
 * This class figurers out which specific command is given by a user String input. The methods that deal with comparing a string input
 * to get the closest string from an array list of string is borrowed from my previous machine project.
 */
public class GameCommands {
   private static ArrayList<String> sCommands,sAvailableTools, sAvailableSeeds, sFarmerTypes;


    public GameCommands()
    {
        sCommands = new ArrayList<String>();
        sAvailableTools = new ArrayList<String>();
        sAvailableSeeds = new ArrayList<String>();
        sFarmerTypes = new ArrayList<String>();
        sCommandBank();
        listUnlockableTools();
        listUnlockableSeeds();
        listUnlockableeFarmerTypes();
    }
    /**
     * This method initializes the command elements in an array list of Strings
     * @param sCommand  an array list of strings which will contain command strings
     */
    private void sCommandBank()
    {

        sCommands.add("inventory"); // 
        sCommands.add("next day"); // 
        sCommands.add("time"); // 
        sCommands.add("farm"); //
        sCommands.add("equip item"); //
        sCommands.add("player"); //c
        sCommands.add("help"); 
        sCommands.add("Exit Game");
        sCommands.add("Seeds");
        sCommands.add("history");
    }
    private void listUnlockableeFarmerTypes()
    {
        sFarmerTypes.add("Default");
        sFarmerTypes.add("Registered");
        sFarmerTypes.add("Distinguished");
        sFarmerTypes.add("Legendary");
    }
    /**
     * This method initializes the list of tools available in game.
     */
    private void listUnlockableTools()
    {
        sAvailableTools.add("plow");
        sAvailableTools.add("watering can");
        sAvailableTools.add("fertilizer");
        sAvailableTools.add("pickaxe");
        sAvailableTools.add("shovel");
    }
    /**
     * This method initializes the list of available seeds in game.
     */
    private void listUnlockableSeeds()
    {
        sAvailableSeeds.add("turnip");
        sAvailableSeeds.add("carrot");
        sAvailableSeeds.add("potato");
        sAvailableSeeds.add("rose");
        sAvailableSeeds.add("tulips");
        sAvailableSeeds.add("sunflower");
        sAvailableSeeds.add("mango");
        sAvailableSeeds.add("apple");
    }
    /**
     * This method returns the absolute value of a given input integer
     * @param nNum the input number whose absolute value will be calculated
     * @return the absolute vallue of a nNum
     */
    public static int absValue(int nNum)
    {
        if(nNum<0)
            nNum *= -1;
        return nNum;
    }
    /**
     * This method finds the answer of a base raised to an exponent. Note that it doesn't 
     * bother with negative exponents and will return 0 if given a negative exponent. 
     * @param base  the base number which will be multiplied with itself exp times
     * @param exp  this is the number of times the base number will be multiplied with itself
     * @return  the answer to the base raised to exponent expression, 0 if given negative exponent
     */
    public static int power(int base, int exp)
    {
        int pow = 1;
        if(exp >=0)
            for(int i =0;i< exp;i++)
                pow*=base;
        else
            pow = 0;
        return pow;
    }
    /**
    *compareString will compare two strings with each other just like strcmp. But, this returns the
    *exact distance between the ascii of two strings unlike strcmp which returns random positive, negative, or 0.
    *It will always compare until the length of the shorter string. I used this function so in option modify, or
    *option display, if you input the wrong spelling of an impression, it will guess your intended imptession.
    *
    *@param  sString1  a string input to be compared to the second parameter
    *@param  sString2   a string input to be compared to the first parameter
    *@return - returns the distance between the two strings by adding the differences of the integer values of each 
                character until the end of the shorter string.
    */
    public static int compareString(String sString1, String sString2)//just like strcmp but it returns the exact difference of the ascii of two strings (strcmp returns randomly positive, randomly negative, or 0)
    {
        int length, diff=0, i;
        // find the length of the shorter string
        if(sString1.length()>=sString2.length())
            length = sString2.length();
        else
            length = sString1.length();;
        //get the distance of every character up to the end of the short string
        for(i=0;i<length;i++)
        {
            diff += absValue(Character.getNumericValue(sString1.charAt(i))-Character.getNumericValue(sString2.charAt(i)));
        }
        return diff;
    }
    /**
     * This method gives the index of the closest existing command to the player's input command. This is achieved by finding the
     * string element from an array list which has the minimum distance with the input String.
     * @param String sInput  the input command of the player
     * @return  the index of the closest command in the game's existing list of commands to the player's input commans
     */
        public static int commandChoice(String sInput, ArrayList<String> sBank)//given a string, it will search for its closest match in an array of strings
    {
        int i, nDiff, nMin, nImpIndex =0;
        //base case, set the first element of the list of impressions as the closest distance with the input
        nMin = compareString(sInput, sBank.get(0));
        for(i=1;i<sBank.size();i++)
        {
        //succeeding elements
            nDiff= compareString(sInput, sBank.get(i));
            if(nMin > nDiff)
            {
            //if current element is closer than the previous closest element to the input, update the current as the closest element
                nMin = nDiff;
                nImpIndex=i;
            }
        }
        return nImpIndex;
    }

    public static ArrayList<String> getsCommands() {
        return sCommands;
    }
    public static ArrayList<String> getsAvailableTools() {
        return sAvailableTools;
    }
    public static ArrayList<String> getsAvailableSeeds() {
        return sAvailableSeeds;
    }
    public static ArrayList<String> getsFarmerTypes() {
        return sFarmerTypes;
    }
    
}
