/**
 * This class represents the items which allow the user to perform certain tasks on a tile such as clearing a rock, ploughing the tile, watering a plant, etc.
 */
public class Tools {
    private String sName;
    private float fCost;
    private float fExpGained;
    public Tools(String sName, float fCost, float fExpGained)
    {
        this.sName = sName;
        this.fCost = fCost;
        this.fExpGained = fExpGained;
    }
    
    public String getsName() {
        return sName;
    }
    public float getfCost() {
        return fCost;
    }
    public float getfExpGained() {
        return fExpGained;
    }
}
