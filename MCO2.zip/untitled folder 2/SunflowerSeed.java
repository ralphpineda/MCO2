public class SunflowerSeed extends Seed{
    public SunflowerSeed(){
     super(20,3,"Sunflower",2,3,1,2,1,1,"Flower");
    }
    
}
