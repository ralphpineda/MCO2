/**
 * This project is a farm simulation game. A player can plant seeds, grow plants, harvest products, clear rocks, and etc.
 * @author  Ralph Dawson G. Pinedafarm
 * @version  MCO1
 */

public class Main {
    public static void main(String Args[])
    {
        GamePanel panel = new GamePanel();
        new GameCommands();
        new GameController(panel);
        boolean isExit;
        do{
            isExit = false;//control.issueCommmand();
        }while(!isExit);
    }
}
