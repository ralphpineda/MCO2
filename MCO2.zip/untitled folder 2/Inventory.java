import java.util.ArrayList;
/**
 * This class represents the container of items that the player owns. It contains three different categories of items (inspired by the backpack in Pokemon games) :
 * tools - these are the equipments that allow the user to perform an action on the tiles such as ploughing, watering, or clearing up rocks
 * seed - these are the items that the player can plant on a tile to grow a plant
 * product - these are the objects that can be sold by the player to earn object coins.
 */
public class Inventory {
    private ArrayList<Tools> toolList;
    private ArrayList<Product> productList;

    public Inventory()
    {
        toolList = new ArrayList<Tools>();
        productList = new ArrayList<Product>();
        this.addTools();
    }


   /**
    * This method intializes the tools stored in an inventory.
    * @param tool this is the tool to be added on the player's inventory
    * @return true if the operation is successful as it can fail when the player's inventory is already at full capacity
    */ 
    private void addTools()
    {
        toolList.add(new Plow());
        toolList.add(new WateringCan());
        toolList.add(new Fertilizer());
        toolList.add(new Pickaxe());
        toolList.add(new Shovel());
    }

    /**
     * Thiis method adds a product object to the player's inventory
     * @param product this is the product to be added to the player's inventory
     * @return true if the operation is successful, false if the product does not fit in the inventory's current capacity
     */
    public void addProduct(Product product)
    {
        this.productList.add(product);
    }

    /**
     * This is the getter method for the ArrayList of Products inside the Inventory
     * @return the arraylist of products
     */
    public ArrayList<Product> getProductList() {
        return productList;
    }
 
     /**
     * This is the getter method for the ArrayList of Tools inside the Inventory
     * @return the arraylist of tools
     */
    public ArrayList<Tools> getToolList() {
        return toolList;
    }

    /**
     * This method finds an instance of a tool that matches the given name
     * @param sName  name of the tool 
     * @return  an instance of the tool
     */
    public Tools getTool(String sName)
    {
        int nIndex = GameCommands.commandChoice(sName, GameCommands.getsAvailableTools());
        return toolList.get(nIndex);
    }
    public void setProductList(ArrayList<Product> productList) {
        for(int i =0; i<productList.size();i++)
            this.productList.add(productList.get(i));
    }
}
