public class RoseSeed extends Seed {
    public RoseSeed(){
        super(5,1,"Rose",1,2,0,1,1,1,"Flower");

    }
}
