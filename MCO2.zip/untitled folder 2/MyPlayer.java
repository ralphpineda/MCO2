/**
 * This class represents the player character which contains a name, level, object coin, experience, an Inventory, and an equipped item
 */
public class MyPlayer {
    private int nLevel;
    private float fExp;
    private String sName;
    private Inventory ruckSack;
    private Tools ItemEquipped; //temporary, to show which object the player is currently using
    private Market shop;
    private String sType;
/**
 * This is the constructor method for the player which sets the beginning state of the player to 0 experience points, 0 levels,
 * and 100 object coins
 * @param sName this is the name of the player's character
 */
    public MyPlayer(String sName)
    {
        this.sName = sName;
        shop = new Market();
        fExp = 0;
        nLevel =0;
        ruckSack = new Inventory();
        sType = "Default";
        equipItem(ruckSack.getTool("Plow").getsName());
    }

/**
 *  This method equips a specified tool for the player. The player must equip the tool before using it.
 *  The String input can be mispelled, the closest tool to the mispelled input will be computed for.
 * @param sInput  the name of the tool to be equipped by the player
 */
    public void equipItem(String sName)
    { 
        ItemEquipped = ruckSack.getTool(sName);
    }
    public void harvestProduct(Tiles tile)
    {
        ruckSack.setProductList(tile.getSeed().getProductList());
        shop.sellProduce(tile.getSeed().getProductList(), sType,tile.getSeed().getnWaterCount(),tile.getSeed().getnFertilCount());  
        setfExp( fExp+= tile.getSeed().getProductList().get(0).getfExp()*tile.getSeed().getProductList().size());
        tile.harvest();
        
    }
    /**
     * This method is for imposing the necessary consequences of using a tool such as gaining experience and losing object coins.
     * @param player  the player using the tool, this is to set the player's experience and object coins
     * @return  true if player has enough money to use the tool, otherwise false.
     */
    public boolean useTool()
    {
        boolean isUsed = false;
        if(shop.getObjCoin()>ItemEquipped.getfCost())
        {
            setfExp(fExp+=ItemEquipped.getfExpGained());
            new GameView().displayObjExp((ItemEquipped.getfCost()*-1), ItemEquipped.getfExpGained());
            isUsed = true;
        }
            //System.out.println("You lack the necessary funds to use a"+ sName + ".");   
        return isUsed;
    }
    public boolean registerType()
    {
        int nRank = 0, nTemp;
        
        boolean isRegister = false;
        if(nLevel>=5&&nLevel <10)
            nRank = 2;
        else if(nLevel >=10 && nLevel <15)
            nRank = 3;
        else if(nLevel >=15)
            nRank = 4;

         if(nRank ==0)
            nTemp = nRank+1;
        else
            nTemp = nRank;
            
        if(shop.getObjCoin()>= nRank*100)
        {
            switch(nRank)
            {
               // case 0: System.out.println("You're already a "+GameCommands.getsFarmerTypes().get(nTemp-1)+" farmer."); break;
                case 2: if(sType !="Registered")
                            isRegister = true;
                        break;
                case 3: if(sType !="Distinguished")
                            isRegister = true;
                            break;
                case 4: if(sType !="Legendary")
                            isRegister = true;
                            break;
            }
            if(isRegister)
            {
                sType = GameCommands.getsFarmerTypes().get(nTemp-1);
                System.out.println("Congratulaions! You're now a "+GameCommands.getsFarmerTypes().get(nTemp-1)+" farmer.\n\n");
            }else
               System.out.println("You're already a "+GameCommands.getsFarmerTypes().get(nTemp-1)+" farmer.");
        }
        return isRegister;
    }

    public String getsName() {
        return sName;
    }
    public Tools getsItemEquipped() {
        return ItemEquipped;
    }
    public float getfExp() {
        return fExp;
    }
    public int getnLevel() {
        return nLevel;
    }
    public Inventory getRuckSack() {
        return ruckSack;
    }

    public void setfExp(float fExp) {
        this.fExp = fExp;
        setnLevel((int)fExp/100);

    }
    public void setnLevel(int nLevel) {
        this.nLevel = nLevel;
    }
    public Market getShop() {
        return shop;
    }
    public String getsType() {
        return sType;
    }



    
}
