public class MangoSeed extends Seed{
    public MangoSeed(){
        super(100,10,"Mango",7,7,4,4,5,15,"Fruit Tree");

    }
    
}
