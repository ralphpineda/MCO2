import java.util.ArrayList;
/**
 * This class handles most of the system output display of the program
 */
public class GameView {
/**
 * This method displays the current date
 * @param gameTime  this is the time object of the game
 */
    public void displayTime(Time gameTime)
    {
        System.out.println("Date (MM/DD/YY): "+ gameTime.getnMonth()+"/"+gameTime.getnDay()+"/"+gameTime.getnYear());
        System.out.println("\n\n");
    }
/**
 * This method displays the farm's tiles and the current game date
 * @param farm  the farm instance to be displayed
 * @param gameTime  the time instance
 */
    public void displayFarm(FarmLand farm, Time gameTime)
    {
        displayTime(gameTime);
        for(int i=0;i< farm.getnTilesRow();i++)
        {
            for(int j =0;j<farm.getnTilesCol();j++ )
            {
                if(farm.getTile(i, j).getIsEmpty() == true)
                {
                    if(farm.getTile(i, j).getIsPlowed() ==true)
                        System.out.printf("%-15s","Plowed");
                     else
                        System.out.printf("%-15s","Unplowed");
                }else if(farm.getTile(i, j).getHasObstacle() == true)
                    System.out.printf("%-15s", farm.getTile(i, j).getObstacle().getsName());
                else if(farm.getTile(i,j).getHasPlant() == true)
                {
                    if(farm.getTile(i, j).getSeed().getIsMature())
                      System.out.printf("%-15s", ("(H) ".concat(farm.getTile(i, j).getSeed().getsName())));
                    else if(!farm.getTile(i, j).getSeed().getIsMature())
                    {
                        if(farm.getTile(i, j).getSeed().getIsWithered())
                            System.out.printf("%-15s", "Withered Plant");
                        else
                            System.out.printf("%-15s", farm.getTile(i, j).getSeed().getsName());
                    }
                }
                    
            }
            System.out.print("\n\n");
        }
    }
/**
 * This method displays the listt of commands available in the game
 */
    public void displayCommands()
    {
        System.out.println("Commands List:");
        for(int i =0; i<GameCommands.getsCommands().size();i++)
            System.out.println(GameCommands.getsCommands().get(i));
        System.out.println("\n\n");
    }
/**
 * This method shows the obbjects contained in the player's inventory
 * @param bag  this is the inventory to be displayed
 */
    public void displayInventory(Inventory bag)
    {
        System.out.println("Inventory: ");
        System.out.println("\n\nA. Tools");
        for(int i =0; i<bag.getToolList().size();i++)
        {
            System.out.println((i+1) + ". " + bag.getToolList().get(i).getsName());
        }
        System.out.println("\n\nB. Products Sold");
        for(int k =0; k<bag.getProductList().size();k++)
        {
            System.out.println((k+1)+". "+bag.getProductList().get(k).getsName());
        }
        System.out.println("\n\n");
    }
/**
 * This method shows the options the player can choose from when interacting with an empty tile
 */
    public void interactEmptyTile()
        {
            System.out.println("1. Use tool\n2. Plant Seed");
            System.out.println("\n\n");
        }
        /**
         * This method shows the options the player can choose to do when interacting with an occupied tile
         * @param seed  this is the seed contained in the tile since there will be an option for harvest when
         *              the seed is ready for harvest
         */
    public void interactOccupiedTile(Seed seed)
    {
        if(seed.getIsMature() )
            System.out.println("1. Use tool\n 2. View Details\n3. Harvest Products");
        else
            System.out.println("1. Use tool\n 2. View Details");
        System.out.println("\n\n");
    }
    /**
     * This method displays the details of the object occupying a tile
     * @param tile  this is the tile which contains the object whose details
     * will be displayed
     */
    public void displayObjDetails(Tiles tile)
    {
        if(tile.getHasPlant())
        {
            System.out.println("Crop Name: "+tile.getSeed().getsName());
            System.out.println("Crop Type: "+tile.getSeed().getsCropType());
            System.out.println("Current Water Count: "+tile.getSeed().getnWaterCount());
            System.out.println("Minimum Water: "+tile.getSeed().getnWaterMin());
            System.out.println("Maximum Water : "+tile.getSeed().getnWaterMax());
            System.out.println("Current Fertilizer Count: "+tile.getSeed().getnFertilCount());
            System.out.println("Minimum Fertilizer: "+tile.getSeed().getnFertilMin());
            System.out.println("Maximum Fertilizer : "+tile.getSeed().getnFertilMax());
            System.out.println("Current Age: "+tile.getSeed().getnAge());
            System.out.println("Days until harvest : "+(tile.getSeed().getnHarvestTime()-tile.getSeed().getnAge()));
            if(tile.getSeed().getIsMature())
            {
                System.out.println("This crop is ready for harvest.");
                for(int i =0; i<tile.getSeed().getProductList().size();i++)
                    System.out.println((i+1)+". "+tile.getSeed().getProductList().get(i).getsName());  
            }
        }else if(tile.getObstacle().getsName() =="Rock")
        {
            System.out.println("You may use a pickaxe to clear this rock");
        }else
            System.out.println("You may use a shovel to clear this withered plant");
        System.out.println("\n\n");
    }
    /**
     * This method displays the stats of the player such as the name, type, level, experience, object coin, and equipped item
     * @param player  this is the player whose stats will be displayed
     */
    public void displayPlayerStats(MyPlayer player)
    {
        System.out.printf("%-15s","Name");
        System.out.println(player.getsName());
        System.out.printf("%-15s","Farmer Type");
        System.out.println(player.getsType());
        System.out.printf("%-15s","Level");
        System.out.println(player.getnLevel());
        System.out.printf("%-15s","Experience");
        System.out.println(player.getfExp());
        System.out.printf("%-15s","Object Coin");
        System.out.println(player.getShop().getObjCoin());
        System.out.printf("%-15s","Equipped Item");
        System.out.println(player.getsItemEquipped().getsName());
        System.out.println("\n\n");
    }
    /**
     * This method displays all the seeds available in game that the player may buy
     */
    public void displaySeedList()
    {
        for(int i=0; i< GameCommands.getsAvailableSeeds().size();i++)
        {
            System.out.println((i+1)+".  "+GameCommands.getsAvailableSeeds().get(i));
        }
    }
    /**
     * This is prompted when the player equips an item
     * @param tool  the item to be equipped
     */
    public void displayItemEquip(Tools  tool)
    {
        System.out.println(tool.getsName()+" is now equipped.\n\n\n");
    }
    /**
     * This method displays all the tools available in game
     */
    public void displayTools()
    {
        for(int i= 0; i<GameCommands.getsAvailableTools().size();i++)
            System.out.println(GameCommands.getsAvailableTools().get(i));
    }
    /**
     * This method displays the name of the products contained in an array list of products
     * @param productList
     */
    public void displayProducts(ArrayList<Product> productList)
    {
        for(int i=0; i<productList.size();i++)
            System.out.println((i+1) +" "+productList.get(i).getsName());
        System.out.println("\n\n");
    }
    /**
     * this method displays the object coins and experience gained when performing an action
     * @param fObj  the object coin added/deducted
     * @param fExp  the experience gained
     */
    public void displayObjExp(float fObj, float fExp)
    {
        System.out.println(fObj+"  Object Coins.");
        System.out.println(fExp+" Experience Points");
        System.out.println("\n\n");
    }
}
