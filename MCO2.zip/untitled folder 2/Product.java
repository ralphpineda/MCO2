public class Product {
    private String sName;
    private float fPrice;
    private float fExp;
    private String sCropType;
    
    public Product(String sName, float fPrice, float fExp, String sCropType)
    {
        this.sName = sName;
        this.fPrice = fPrice;
        this.fExp = fExp;
        this.sCropType = sCropType;
    }
    public String getsName() {
        return sName;
    }
    public float getfPrice() {
        return fPrice;
    }
    public float getfExp() {
        return fExp;
    }
    public String getsCropType() {
        return sCropType;
    }
    public void setfPrice(float fPrice) {
        this.fPrice = fPrice;
    }
}
