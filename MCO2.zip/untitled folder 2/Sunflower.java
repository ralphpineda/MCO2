public class Sunflower extends Product {
    public Sunflower(){
        super("Sunflower", 19, (float)7.5, "Flower");
    }
    
}
